from django.contrib import admin
from django.urls import path
from home import views
from django.urls import path
# from .views import AboutView

urlpatterns = [
    path("", views.index, name='home'),
    path("index.html", views.index, name='home'),
    path("about.html", views.about, name='about'),
    path("blog.html", views.blog, name='blog'),
    path("shop.html", views.shop, name='shop'),
]